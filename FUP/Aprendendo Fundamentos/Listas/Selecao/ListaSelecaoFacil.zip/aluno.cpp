//1 pt
/* Retornar o maior de dois numeros A e B dados como entrada. */
int valor_maximo2 (int num1, int num2)
{

}

//1 pt
/* Retornar true se o valor de A for maior que o de B e C*/
bool a_eh_maior(int A, int B, int C)
{

}

//1 pt
/* Retornar o maior dos numeros A e B e C dados como entrada. */
int valor_maximo3 (int a, int b, int c)
{

}

//2 pts
/* Retornar o maior dos numeros A e B e C e D dados como entrada. */
int valor_maximo4 (int a, int b, int c, int d)
{

}

//DICA: use uma variavel maximo que inicie com o valor de A e va
//mudando de valor caso os outros sejam menores

 //2 pt
/* Retornar true se A esta entre os numeros B e C. */
bool a_esta_meio (int A, int B, int C)
{

}
//A eh o do meio se for maior que B e menor que C ou maior que C e menor que B

//1 pt
/* Dados dois numeros naturais como entrada, determinar o resto da
* divisao do  primeiro pelo segundo quando possiÂ­vel. */
int resto_divisao (int n1, int n2)
{

}

//1 pt
/* Dados dois numeros naturais como entrada, determinar o resto da
* divisao do maior pelo menor. */
int resto_divisao_maior (int n1, int n2)
{

}

//Dica: se n1 for maior que n2 faca n1%n2, senao faca n2%n1

//1 pt
/* Elabore um programa receba um numero e retorne true se ele
* for par */
bool eh_par (int num)
{

}

//1 pt
/* Retorne verdadeiro se o numero passado for multiplo de 3 */
bool eh_mult3 (int num)
{

}

//1 pt
/* Retorne verdadeiro se o numero passado for multiplo do segundo */
bool eh_mult (int num1, int num2)
{

}

//1 pt
/* Retorne verdadeiro se o resto da divisao do numero num por 3
* for igual a 1 e tambem num for divisivel por 5*/
bool eh_sobra31_div5 (int num)
{

}

//1 pt
/* Retorne verdadeiro se o num por par, mas nao for divisivel
* por 4 nem por 6.*/
bool eh_par_n46 (int num)
{

}


//2 pt
/*
* Faca um algoritmo que receba dois numeros inteiros e verifique se ha
* a seguinte situacao: se o n1 esta entre 50 e 200 e n2 esta entre -1 e 9.
* A saida deve ser true se os numeros satisfazem a situacao e 0
* se nao satisfazem. */
int satisfaz_situacao (int n1, int n2)
{

}

//1 pt
/* Se o numero for negativo, inverter deixando positivo e retornar.
* Se for positivo, retornar o valor positivo.
*/
int modulo (int num)
{

}


//1 pt
/* Se o numero por positivo, retornar o numero multiplicado por 5,
* se for negativo retorne o numero subtraido de 3 */
int operacao (int num)
{

}

//2 pt
/* Pegue o resto da divisao entre num1 e num2 e multiplique por num1.
* Se o resultado for par, divida por 2. Retorne o resultado.*/
int operacao2 (int num1, int num2)
{

}

//2 pt
/* Se num1 e num2 forem ambos divisiveis por 3 ou forem ambos divisiveis
* por 5 retorne true */
int ambos_3_ou_ambos_5 (int num1, int num2)
{

}

//1 pt
/*Retorne true se o resto da divisao de num1 por num2 for igual ao
 * resto da divisao de num3 por num4.*/
int restos_iguais (int num1, int num2, int num3, int num4)
{

}

//2 pt
//Se o numero for divisivel por 3 retorne 1, se for divisivel por 5 retorne 2,
//se for divisiÂ­vel por 3 e por 5 ao mesmo tempo retorne 3.
int div_35 (int num)
{

}
